const express = require('express');
const upload = require('express-fileupload');
const path = require('path')
const fs = require('fs')
const v8 = require('v8')
// const button = document.getElementById('#filter');
const app = express()

// ------------------------------------checking heap memory-------------------------------------------------
// console.log(v8.getHeapSpaceStatistics());
// const totalHeap = v8.getHeapSpaceStatistics().space_available_size
// let Totalheapsize = (totalHeap/1024 / 1024/ 1024).toFixed(2)
// console.log(`Total heap size in bytes ${totalHeap}, (GB ${Totalheapsize})`)

app.use(upload())

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html')
})

app.post('/', (req, res) => {
    if (req.files) {
        console.log(req.files)
        var file = req.files.file
        var mainFileName = file.name
        var mainFileTrim = path.parse(mainFileName).name
        var mainFileYear = mainFileTrim.substring(mainFileTrim.length - 4);
        console.log(mainFileName)
        console.log(mainFileTrim)
        console.log(mainFileYear)


        file.mv('./upload/' + mainFileName, function (err) {
            if (err) {
                res.send(err)
            }
        })
        console.log(mainFileName)

        const checkTime = 1000;
        function check() {
            setTimeout(() => {
                fs.readFile("./upload/" + mainFileName, 'utf8', function (err, data) {
                    if (err) {
                        // got error reading the file, call check() again
                        check();
                    } else {

                        var AdmZip = require("adm-zip");
                        var zip = new AdmZip('./upload/' + mainFileName);
                        var path = require('path')
                        var fs = require('fs');
                        var JSZip = require("jszip");
                        var zipEntries = zip.getEntries(); // an array of ZipEntry records

                        //------------------------------------------- Extracting unwanted Files---------------------------------------

                        zipEntries.forEach(function (zipEntry) {
                            // console.log(zipEntry.toString()); 

                            var nameofFile = zipEntry.entryName;
                            var onlyName = path.parse(nameofFile).name
                            var onlyYear = onlyName.substring(onlyName.length - 4);
                            // console.log(fileYear);
                            //---------------------------- Creating Folders-------------------------

                            if (onlyYear != mainFileYear) {
                                // console.log("File is in wrong folder " + name);
                                if (!fs.existsSync(onlyName)) {

                                    fs.mkdir(path.join('./filtered_files/'+mainFileTrim+'/', onlyYear), (err) => {
                                        if (err) {
                                            // return console.error(err);
                                        }
                                        // console.log("Folder created successsfully");

                                    });
                                }

                                //----------------------------- Extracting Files-------------------------

                                console.log(nameofFile);
                                zip.extractEntryTo(/*entry name*/nameofFile, /*target path*/ './filtered_files/'+mainFileTrim+'/' + onlyYear, false, true);



                            }
                        })


                        // ------------------------------------------- Deleting unwanted Files---------------------------------------
                        fs.readFile('./upload/' + mainFileName, function (err, data) {
                            if (err) throw err;
                            JSZip.loadAsync(data).then(function (zip) {
                                zip.forEach((err, entry) => {
                                    const nameofFile = (entry.name);
                                    const onlyName = path.parse(nameofFile).name;
                                    const onlyYear = onlyName.substring(onlyName.length - 4);


                                    if (onlyYear != mainFileYear) {
                                        // fs.writeFileSync('./extracted/'+onlyYear, nameofFile);
                                        zip.remove(nameofFile);
                                    }
                                })

                                zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
                                    .pipe(fs.createWriteStream('./filtered_files/'+mainFileTrim+'/' + 'new_' + mainFileName))
                                    .on('finish', function () {

                                        console.log("Zip file is Filtered according to years");

                                    });
                            });
                        });
                    }
                });
            }, checkTime)
        }

        check();

    }

})

app.listen(5000)
console.log("open localhost:5000 in browser");


